import javax.swing.*;
import javax.swing.plaf.DimensionUIResource;
import javax.swing.plaf.LabelUI;

import java.awt.*;
import javax.xml.catalog.CatalogFeatures.Feature;
import java.awt.Toolkit;

public class JavaGUI {
    private int x , y ;
    
    JavaGUI(){
        
        JFrame frame = new JFrame("IchiRaku Raman Shop ");
        ImageIcon logo = new ImageIcon("Logo.jpg");
        

       
        frame.setSize(300, 300);
        frame.setLayout(null);
        frame.setSize(500,500);
        frame.setResizable(true);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setIconImage((logo.getImage()));
        frame.getContentPane().setBackground(new Color(130,126,192));
    }

    public static void main(String[] args) {
        
        ///************** Label ************** */ 
        JLabel label = new JLabel();
        JPanel panel = new JPanel(); 
        ImageIcon bgImage = new ImageIcon("bg_image.png");
        label.setIcon(bgImage);
        label.setOpaque(false);
        label.setText("shdfjk");
        label.setVerticalTextPosition(JLabel.TOP);
        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setVerticalAlignment(JLabel.CENTER);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setLayout(null);
        label.setBounds(60,40 ,1200, 800);



        panel.setBounds(0,0,500,500);
		panel.setLayout(null);
		panel.setBackground(new Color(126,130,192));

        
        /// ******* Frame *************
        JFrame frame = new JFrame("IchiRaku Raman Shop ");
        ImageIcon logo = new ImageIcon("Logo.jpg");
        frame.setLayout(null);
        frame.setSize(1200,800);
        panel.add(label);

        frame.setResizable(true);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setIconImage((logo.getImage()));
        frame.getContentPane().setBackground(new Color(255,126,192));
        frame.add(panel);

        
}
}